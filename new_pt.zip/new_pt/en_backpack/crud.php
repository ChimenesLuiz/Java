return [

    /*
    |--------------------------------------------------------------------------
    | Linhas de Idioma do CRUD do Backpack
    |--------------------------------------------------------------------------
    |
    | As seguintes linhas de idioma são usadas pela interface CRUD.
    | Você é livre para alterá-las para se adequar melhor às suas visualizações
    | e personalizar sua aplicação.
    |
    */

    // Formulários
    'save_action_save_and_new'         => 'Salvar e criar novo item',
    'save_action_save_and_edit'        => 'Salvar e editar este item',
    'save_action_save_and_back'        => 'Salvar e voltar',
    'save_action_save_and_preview'     => 'Salvar e visualizar',
    'save_action_changed_notification' => 'Comportamento padrão após salvar foi alterado.',

    // Formulário de Criação
    'add'                 => 'Adicionar',
    'back_to_all'         => 'Voltar para todos ',
    'cancel'              => 'Cancelar',
    'add_a_new'           => 'Adicionar um novo ',

    // Formulário de Edição
    'edit'                 => 'Editar',
    'save'                 => 'Salvar',

    // Modelos Traduzíveis
    'edit_translations' => 'Tradução',
    'language'          => 'Idioma',

    // Visualização da tabela CRUD
    'all'                       => 'Todos ',
    'in_the_database'           => 'no banco de dados',
    'list'                      => 'Lista',
    'reset'                     => 'Redefinir',
    'actions'                   => 'Ações',
    'preview'                   => 'Visualizar',
    'delete'                    => 'Excluir',
    'admin'                     => 'Admin',
    'details_row'               => 'Esta é a linha de detalhes. Modifique como desejar.',
    'details_row_loading_error' => 'Ocorreu um erro ao carregar os detalhes. Por favor, tente novamente.',
    'clone'                     => 'Clonar',
    'clone_success'             => '<strong>Entrada clonada</strong><br>Foi adicionada uma nova entrada com as mesmas informações desta.',
    'clone_failure'             => '<strong>Falha na clonagem</strong><br>Não foi possível criar a nova entrada. Por favor, tente novamente.',

    // Mensagens de Confirmação e Balões
    'delete_confirm'                              => 'Tem certeza de que deseja excluir este item?',
    'delete_confirmation_title'                   => 'Item Excluído',
    'delete_confirmation_message'                 => 'O item foi excluído com sucesso.',
    'delete_confirmation_not_title'               => 'Não excluído',
    'delete_confirmation_not_message'             => 'Ocorreu um erro. Seu item pode não ter sido excluído.',
    'delete_confirmation_not_deleted_title'       => 'Não excluído',
    'delete_confirmation_not_deleted_message'     => 'Nada aconteceu. Seu item está seguro.',

    // Ações em Massa
    'bulk_no_entries_selected_title'   => 'Nenhuma entrada selecionada',
    'bulk_no_entries_selected_message' => 'Selecione uma ou mais entradas para executar uma ação em massa sobre elas.',

    // Excluir em Massa
    'bulk_delete_are_you_sure'   => 'Tem certeza de que deseja excluir essas :number entradas?',
    'bulk_delete_sucess_title'   => 'Entradas excluídas',
    'bulk_delete_sucess_message' => ' entradas foram excluídas',
    'bulk_delete_error_title'    => 'Falha na exclusão',
    'bulk_delete_error_message'  => 'Uma ou mais entradas não puderam ser excluídas',

    // Clonagem em Massa
    'bulk_clone_are_you_sure'   => 'Tem certeza de que deseja clonar essas :number entradas?',
    'bulk_clone_sucess_title'   => 'Entradas clonadas',
    'bulk_clone_sucess_message' => ' entradas foram clonadas.',
    'bulk_clone_error_title'    => 'Falha na clonagem',
    'bulk_clone_error_message'  => 'Uma ou mais entradas não puderam ser criadas. Por favor, tente novamente.',

    // Erros Ajax
    'ajax_error_title' => 'Erro',
    'ajax_error_text'  => 'Erro ao carregar a página. Atualize a página, por favor.',

    // Tradução do DataTables
    'emptyTable'     => 'Nenhum dado disponível na tabela',
    'info'           => 'Exibindo _START_ a _END_ de _TOTAL_ entradas',
    'infoEmpty'      => 'Nenhuma entrada',
    'infoFiltered'   => '(filtrado de _MAX_ entradas totais)',
    'infoPostFix'    => '.',
    'thousands'      => ',',
    'lengthMenu'     => '_MENU_ entradas por página',
    'loadingRecords' => 'Carregando...',
    'processing'     => 'Processando...',
    'search'         => 'Buscar',
    'zeroRecords'    => 'Nenhuma entrada correspondente encontrada',
    'paginate'       => [
        'first'    => 'Primeira',
        'last'     => 'Última',
        'next'     => 'Próxima',
        'previous' => 'Anterior',
    ],
    'aria' => [
        'sortAscending'  => ': ativar para classificar a coluna em ordem ascendente',
        'sortDescending' => ': ativar para classificar a coluna em ordem descendente',
    ],
    'export' => [
        'export'            => 'Exportar',
        'copy'              => 'Copiar',
        'excel'             => 'Excel',
        'csv'               => 'CSV',
        'pdf'               => 'PDF',
        'print'             => 'Imprimir',
        'column_visibility' => 'Visibilidade de coluna',
    ],

    // CRUD global - erros
    'unauthorized_access' => 'Acesso não autorizado - você não possui as permissões necessárias para ver esta página.',
    'please_fix'          => 'Por favor, corrija os seguintes erros:',

    // CRUD global - notificações de sucesso/erro
    'insert_success' => 'O item foi adicionado com sucesso.',
    'update_success' => 'O item foi modificado com sucesso.',

    // Visualização de Reordenar CRUD
    'reorder'                      => 'Reordenar',
    'reorder_text'                 => 'Use arrastar e soltar para reordenar.',
    'reorder_success_title'        => 'Concluído',
    'reorder_success_message'      => 'A sua ordem foi salva.',
    'reorder_error_title'          => 'Erro',
   
