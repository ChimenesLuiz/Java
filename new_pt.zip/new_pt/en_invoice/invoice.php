return [

    /*
    |--------------------------------------------------------------------------
    | Linhas de Idioma para Fatura
    |--------------------------------------------------------------------------
    */

    'serial'          => 'Número de Série',
    'date'            => 'Data da Fatura',
    'seller'          => 'Vendedor',
    'buyer'           => 'Comprador',
    'address'         => 'Endereço',
    'code'            => 'Código',
    'vat'             => 'Código de Imposto sobre Valor Agregado (IVA)',
    'phone'           => 'Telefone',
    'description'     => 'Descrição',
    'units'           => 'Unidades',
    'quantity'        => 'Quantidade',
    'price'           => 'Preço',
    'discount'        => 'Desconto',
    'tax'             => 'Imposto',
    'sub_total'       => 'Subtotal',
    'total_discount'  => 'Total de Desconto',
    'taxable_amount'  => 'Valor Tributável',
    'total_taxes'     => 'Total de Impostos',
    'tax_rate'        => 'Taxa de Imposto',
    'total_amount'    => 'Valor Total',
    'pay_until'       => 'Por favor, pague até',
    'amount_in_words' => 'Valor em Palavras',
    'notes'           => 'Notas',
    'shipping'        => 'Envio',

];
